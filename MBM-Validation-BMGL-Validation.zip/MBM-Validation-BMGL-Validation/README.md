# MBM-Validation
Experiments and results obtained from the validation of our MBM notation

BMGL VALIDATION RESULTS

Thank you for your interest in BMGL. The results of our experiments are found in the Excel File "bmgl_results" which has 7 sheets that contain the results and analysis gathered from the execution of the experiments. All results are anonymous. The sheets are indexed as follows:

1.Interpretation Questionnaire: This sheet has the answers from the subjects who performed the interpretation experiment. The answers to each question are found in the sheet.

2.Modeling Questionnaire: This sheet has the answers from the subjects who performed the modeling experiment.

3.Results: This sheet presents all the results from the experiment converted to a quantitative scale to enable their analysis.

4.Histograms: This sheet has the main results obtained after analyzing the answers given by subjects. The sheet also presents the histograms made for each question.

5.Interpretation Grades: This sheet has the grades obtained by the students in the interpretation experiment.

6. Modeling Grades: This sheet has the grades obtained by the students in the modeling experiment.

7. Overall Grades: This sheet has the results obtained after analyzing the grades obtained by students.
